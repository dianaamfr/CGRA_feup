/**
 * MyTangram
 * @constructor
 * @param scene - Reference to MyScene object
 */
class MyTangram extends CGFobject {
	constructor(scene) {
        super(scene);
        this.diamond = new MyDiamond(scene);
        this.trOrange = new MyTriangle(scene);
        this.trBlue = new MyTriangle(scene);
        this.trRed = new MyTriangle(scene);
        this.trPink = new MyTriangle(scene);
        this.trPurple = new MyTriangle(scene);
        this.parallelogram = new MyParallelogram(scene);
	}
	display(){

        var rot = [Math.cos(graToRad(45)), Math.sin(graToRad(45)), 0.0, 0.0,
            -Math.sin(graToRad(45)), Math.cos(graToRad(45)), 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0,
            0.0, 0.0, 0.0, 1.0];

        var trl = [1.0,0.0, 0.0, 0.0,
                    0.0,1.0,0.0,0.0,
                    0.0, 0.0, 1.0, 0.0,
                -1.5, -0.25, 0.0, 1.0];

        var sca2 = [Math.sqrt(2)/2, 0.0, 0.0, 0.0,
                    0.0, Math.sqrt(2)/2, 0.0, 0.0,
                    0.0, 0.0, Math.sqrt(2)/2, 0.0,
                    0.0, 0.0, 0.0, 1.0];

        this.scene.pushMatrix();
        this.scene.multMatrix(trl);
        this.scene.multMatrix(sca2);
        this.scene.multMatrix(rot);
        this.diamond.display();
        this.scene.popMatrix();

        this.scene.pushMatrix();
        this.scene.translate(0,1,0);
        this.trOrange.display();  
        this.scene.popMatrix();      

        this.scene.pushMatrix();
        this.scene.translate(0,-1,0);
        this.scene.rotate(graToRad(-90),0,0,1);
        this.trBlue.display();  
        this.scene.popMatrix();  

        this.scene.pushMatrix();
        this.scene.translate(-2.5,-0.25,0);
        this.scene.scale(1/2,1/2,1);
        this.scene.rotate(graToRad(-180),0,0,1);
        this.trRed.display();  
        this.scene.popMatrix();  

        this.scene.pushMatrix();
        this.scene.translate(-2.3,0.95,0);
        this.scene.scale(0.7,0.7,1);
        this.trPink.display();  
        this.scene.popMatrix();  

        this.scene.pushMatrix();
        this.scene.translate(1.0,-0.7,0);
        this.scene.rotate(graToRad(225),0,0,1);
        this.scene.scale(1/2,1/2,1);
        this.trPurple.display();  
        this.scene.popMatrix();  

        this.scene.pushMatrix();
        this.scene.translate(1.0,0,0);
        this.scene.scale(0.7,0.7,1);
        this.parallelogram.display();  
        this.scene.popMatrix(); 
    }
}
